(function ()
{
    'use strict';

    angular
        .module('fuse');
})();
